/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arearectangle;

import java.util.Scanner;

/**
 *
 * @author ajat1
 */
public class AreaRectangle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int length = 0;
        int width = 0;
        int area = 0;
        
        System.out.print("Enter the first side of the rectangle: ");
        length = sc.nextInt();
        System.out.print("What is the second side of the rectangle: ");
        width = sc.nextInt();
        area = length * width;
        System.out.println("The area of the rectangle is " 
                + area + "." );
        
    }
    
}
